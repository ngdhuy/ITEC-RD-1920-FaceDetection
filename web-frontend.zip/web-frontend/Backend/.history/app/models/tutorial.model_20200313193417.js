// module.exports = (sequelize, Sequelize) => {
//   const Tutorial = sequelize.define("tutorial", {
//     title: {
//       type: Sequelize.STRING
//     },
//     description: {
//       type: Sequelize.STRING
//     },
//     published: {
//       type: Sequelize.BOOLEAN
//     }
//   });

//   return Tutorial;
// };
module.exports = (sequelize, DataTypes)  {
  const Class = sequelize.define("class", {
    class_id:{
      type:DataTypes.UUID,
      defaultValue: Sequelize.UUIDV1,
      allowNull: false,
      primaryKey: true
    },
    total:{
      type:DataTypes.INTEGER
    },
    class_name:{
      type:DataTypes.STRING
    }
  },{ freezeTableName: true,
    timestamps: false
  });

 
};