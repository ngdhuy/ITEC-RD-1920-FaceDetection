// module.exports = (sequelize, Sequelize) => {
//   const Tutorial = sequelize.define("tutorial", {
//     title: {
//       type: Sequelize.STRING
//     },
//     description: {
//       type: Sequelize.STRING
//     },
//     published: {
//       type: Sequelize.BOOLEAN
//     }
//   });

//   return Tutorial;
// };
module.exports = (sequelize, Sequelize) => {
  const Tutorial = sequelize.define("class", {
    class_id:{
      type:Sequelize.UUID,
      defaultValue: Sequelize.UUIDV1,
      allowNull: false,
      primaryKey: true
    },
    total:{
      type:Sequelize.INTEGER
    },
    class_name:{
      type:Sequelize.STRING
    }
  },{ freezeTableName: true,
    timestamps: false
  });
return Tutorial
 
};