module.exports = app => {
  const account = require("../controllers/account.controller.js");

  var router = require("express").Router();

  // Create a new Tutorial
  router.post("/signup", account.create);

  router.post("/login", account.login);



  // Retrieve all Tutorials
  router.get("/", account.findAll);

  // // Retrieve all published Tutorials
  // router.get("/published", class_room.findAllPublished);

  // Retrieve a single Tutorial with id
  router.get("/:id", account.findOne);

  // Update a Tutorial with id
  router.put("/:id", account.update);

  // Delete a Tutorial with id
  router.delete("/:id", account.delete);

  // Create a new Tutorial
  router.delete("/", account.deleteAll);

  app.use('/api/account', router);
};
