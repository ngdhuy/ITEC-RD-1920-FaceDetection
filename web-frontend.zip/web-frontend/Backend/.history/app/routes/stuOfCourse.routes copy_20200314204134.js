module.exports = app => {
  const stuOfCourse = require("../controllers/stuOfCourse.controller.js");

  var router = require("express").Router();

  // Create a new Tutorial
  router.post("/", stuOfCourse.create);

  // Retrieve all Tutorials
  router.get("/", stuOfCourse.findAll);

  // // Retrieve all published Tutorials
  // router.get("/published", class_room.findAllPublished);

  // Retrieve a single Tutorial with id
  router.get("/:id", stuOfCourse.findOne);

  // Update a Tutorial with id
  router.put("/:id", stuOfCourse.update);

  // Delete a Tutorial with id
  router.delete("/:id", stuOfCourse.delete);

  // Create a new Tutorial
  router.delete("/", stuOfCourse.deleteAll);

  app.use('/api/studentofcourse', router);
};
