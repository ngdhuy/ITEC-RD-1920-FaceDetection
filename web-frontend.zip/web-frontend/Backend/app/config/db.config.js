module.exports = {
  HOST: "localhost",
  USER: "postgres",
  PASSWORD: "Luadao130998@",
  DB: "R&D",
  dialect: "postgres",
  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000
  }
};
