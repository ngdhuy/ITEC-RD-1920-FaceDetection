import React, { Component } from 'react'
import { Table, Button, Row, Col } from 'react-bootstrap';
import CourseDataService from '../services/course.service'


class TableAdmin extends Component {
  constructor(props){
    super(props);
    this.del = this.del.bind(this);

  }
  del(course_id){
    let confirmDelete = window.confirm('Delete item forever?')
    if(confirmDelete)
    CourseDataService.delete(course_id)
    .then(response => {
      console.log(response.data);
      this.props.history.push('/course')
      })
      .catch(e => {
          console.log(e);
      });
  }
  render() {

    const courses = this.props.courses.map(course => {
      return (
        <tr key={course.id}>
          <th scope="row">{course.course_id}</th>
          <td>{course.course_name}</td>
          <td>{course.course_start_date}</td>
          <td>{course.course_end_date}</td>
          <td>
            <Button variant="outline-warning">Edit</Button>{' '}
            <Button variant="outline-danger" onClick={() => this.del(course.course_id)}>Delete</Button>
          </td>
          <td>
          </td>
        </tr>
        )
      })

    return (
        
            <Table borderless responsive hover>
        <thead>
          <tr>
            <th>ID</th>
            <th>Course Name</th>
            <th>Start From</th>
            <th>End Day</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {courses}
        </tbody>
      </Table>
      
    )
  }
}

export default TableAdmin