import React, { Component } from 'react'
import { Container, Row, Col } from 'reactstrap'
import CourseDataService from "../services/course.service"
import TableAdmin from './tableAdmin'


class CourseAdmin extends Component {
 constructor(props){
   super(props);

   this.state = {courses: []}
 }

  getItems(){
    CourseDataService.getAll()
      .then(response => {
        console.log(response.data);
        this.setState({courses: response.data})
      })
      .catch(err => console.log(err))
  }

  componentDidMount(){
    this.getItems()
  }

  render() {
    return (
      <Container fluid >
        <Row>
          <Col>
            <h1 style={{margin: "20px 0"}}>Course List</h1>
            
          </Col>
        </Row>
        <Row>
          <Col>
            <TableAdmin courses={this.state.courses} />
          </Col>
        </Row>
      </Container>
    )
  }
}

export default CourseAdmin