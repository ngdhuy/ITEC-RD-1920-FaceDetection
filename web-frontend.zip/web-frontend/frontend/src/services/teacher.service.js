import http from "../http-common";

class TeacherDataService {
  getAll() {
    return http.get("/teacher");
  }

  get(teacher_id) {
    return http.get(`/teacher/${teacher_id}`);
  }

  create(data) {
    return http.post("/teacher", data);
  }

  update(teacher_id, data) {
    return http.put(`/teacher/${teacher_id}`, data);
  }

  delete(teacher_id) {
    return http.delete(`/teacher/${teacher_id}`);
  }

  deleteAll() {
    return http.delete(`/teacher`);
  }

  findByName(name) {
    return http.get(`/teacher?name=${name}`);
  }
}

export default new TeacherDataService();