import http from "../http-common";

class CourseDataService {
  getAll() {
    return http.get("/course");
  }

  get(course_id) {
    return http.get(`/course/${course_id}`);
  }

  create(data) {
    return http.post("/course", data);
  }

  update(course_id, data) {
    return http.put(`/course/${course_id}`, data);
  }

  delete(course_id) {
    return http.delete(`/course/${course_id}`);
  }

  deleteAll() {
    return http.delete(`/course`);
  }

  findByName(course_name) {
    return http.get(`/course?name=${course_name}`);
  }
}

export default new CourseDataService();