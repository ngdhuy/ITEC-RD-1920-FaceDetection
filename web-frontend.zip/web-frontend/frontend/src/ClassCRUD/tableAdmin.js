import React, { Component } from 'react'
import { Table, Button, Row, Col } from 'react-bootstrap';
import ClassDataService from '../services/teacher.service'


class TableAdmin extends Component {
  constructor(props){
    super(props);
    this.del = this.del.bind(this);

  }
  del(class_id){
    let confirmDelete = window.confirm('Delete item forever?')
    if(confirmDelete)
    ClassDataService.delete(class_id)
    .then(response => {
      console.log(response.data);
      this.props.history.push('/class')
      })
      .catch(e => {
          console.log(e);
      });
  }
  render() {

    const classes = this.props.classes.map(oneclass => {
      return (
        <tr key={oneclass.id}>
          <th scope="row">{oneclass.class_id}</th>
          <td>{oneclass.class_name}</td>
          <td>{oneclass.total}</td>
          <td>
            <Button variant="outline-warning">Edit</Button>{' '}
            <Button variant="outline-danger" onClick={() => this.del(oneclass.class_id)}>Delete</Button>
          </td>
          <td>
          </td>
        </tr>
        )
      })

    return (
        
            <Table borderless responsive hover>
        <thead>
          <tr>
            <th>ID</th>
            <th>Class Name</th>
            <th>Total</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {classes}
        </tbody>
      </Table>
      
    )
  }
}

export default TableAdmin