import React, { Component } from "react";
import ClassDataService from "../services/class.service";

 class AddClass extends Component {
  constructor(props) {
    super(props);
    this.onChangeClassId = this.onChangeClassId.bind(this);
    this.onChangeName = this.onChangeName.bind(this);
    this.onChangeTotal = this.onChangeTotal.bind(this);
    this.saveClass = this.saveClass.bind(this);
    this.newClass = this.newClass.bind(this);

    this.state = {
      class_id: null,
      class_name: "",
      total: null,
      submitted: false
    };
  }

  onChangeClassId(e) {
    this.setState({
      class_id: e.target.value
    });
  }

  onChangeName(e) {
    this.setState({
      class_name: e.target.value
    });
  }
  
  onChangeTotal(e) {
    this.setState({
      total: e.target.value
    });
  }

  saveClass() {
    var data = {
      class_id: this.state.class_id,
      class_name: this.state.class_name,
      total: this.state.total
    };

    ClassDataService.create(data)
      .then(response => {
        this.setState({
          class_id: response.data.class_id,
          class_name: response.data.class_name,
          total: response.data.total
        });
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });

    this.setState({
      submitted: true
    });
  }

  newClass() {
    this.setState({
      class_id: null,
      class_name: "",
      total: null,
      submitted: false
    });
  }

  render() {
    return (
      <div className="submit-form">
        {this.state.submitted ? (
          <div>
            <h4>You submitted successfully!</h4>
            <button className="btn btn-success" onClick={this.newClass}>
              Add
            </button>
          </div>
        ) : (
          <div>
            <div className="form-group">
              <label htmlFor="class_id">ID</label>
              <input
                type="number"
                className="form-control"
                id="class_id"
                required
                value={this.state.class_id}
                onChange={this.onChangeClassId}
                name="class_id"
              />
            </div>
            <div className="form-group">
              <label htmlFor="class_name">Class Name</label>
              <input
                type="text"
                className="form-control"
                id="class_name"
                required
                value={this.state.class_name}
                onChange={this.onChangeName}
                name="class_name"
              />
            </div>
            <div className="form-group">
              <label htmlFor="total">Total</label>
              <input
                type="number"
                className="form-control"
                id="total"
                required
                value={this.state.total}
                onChange={this.onChangeTotal}
                name="total"
              />
            </div>
            <button onClick={this.saveClass} className="btn btn-success">
              Submit
            </button>
          </div>
        )}
      </div>
    );
  }
}
export default AddClass