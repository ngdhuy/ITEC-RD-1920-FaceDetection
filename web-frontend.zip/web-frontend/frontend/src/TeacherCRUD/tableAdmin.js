import React, { Component } from 'react'
import { Table, Button, Row, Col } from 'react-bootstrap';
import TeacherDataService from '../services/teacher.service'


class TableAdmin extends Component {
  constructor(props){
    super(props);
    this.del = this.del.bind(this);

  }
  del(teacher_id){
    let confirmDelete = window.confirm('Delete item forever?')
    if(confirmDelete)
    TeacherDataService.delete(teacher_id)
    .then(response => {
      console.log(response.data);
      this.props.history.push('/teacher')
      })
      .catch(e => {
          console.log(e);
      });
  }
  render() {

    const teachers = this.props.teachers.map(teacher => {
      return (
        <tr key={teacher.id}>
          <th scope="row">{teacher.teacher_id}</th>
          <td>{teacher.name}</td>
          <td>{teacher.email}</td>
          <td>{teacher.phone}</td>
          <td>{teacher.gender}</td>
          <td>
            <Button variant="outline-warning">Edit</Button>{' '}
            <Button variant="outline-danger" onClick={() => this.del(teacher.teacher_id)}>Delete</Button>
          </td>
          <td>
          </td>
        </tr>
        )
      })

    return (
        
            <Table borderless responsive hover>
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Gender</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {teachers}
        </tbody>
      </Table>
      
    )
  }
}

export default TableAdmin