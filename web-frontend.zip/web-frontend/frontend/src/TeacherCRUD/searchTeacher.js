import React, {Component} from 'react'
import TeacherDataService from '../services/teacher.service'
import {Table,Button} from 'react-bootstrap'

class SearchTeacher extends Component {
    constructor(props) {
        super(props);
        this.onChangeSearchName = this.onChangeSearchName.bind(this);
        this.searchName = this.searchName.bind(this);
        
        this.state = {
            teachers: [],
            currentTeacher: null,
            currentIndex: -1,
            searchName: ""
        }
    }

    onChangeSearchName(e){
        const searchName = e.target.value;
        this.setState({
            searchName: searchName
        })
    }

    searchName(){
        TeacherDataService.findByName(this.state.searchName)
            .then(response => {
                this.setState({
                    teachers: response.data
                });
                console.log(response.data);
            })
            .catch(e => {
                console.log(e);
            });
    }
    render(){
        return(
         <div class="container-fluid">
            <div>
                <div className="input-group mb-3">
                        <input
                        type="text"
                        className="form-control"
                        placeholder="Search by title"
                        value={this.state.name}
                        onChange={this.onChangeSearchName}
                        />
                    <div className="input-group-append">
                        <button
                            className="btn btn-outline-secondary"
                            type="button"
                            onClick={this.searchName}
                        >
                            Search
                        </button>
                    </div>
                </div>
            </div>
            <div >
                <h4>Teacher List</h4>
                  {  this.state.teachers.map(teacher => {
                        return(
                            <Table borderless responsive>
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>gender</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <th scope="row">{teacher.teacher_id}</th>
                                <td>{teacher.name}</td>
                                <td>{teacher.email}</td>
                                <td>{teacher.phone}</td>
                                <td>{teacher.gender}</td>
                             
                                </tbody>
                            </Table>
                        )
                    })
                }           
            </div>
        </div>
        )
    }
}

export default SearchTeacher