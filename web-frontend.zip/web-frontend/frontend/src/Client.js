import React from 'react'
import {Nav,Navbar,Form,FormControl,Button, Container, Jumbotron,Row, Col,Tabs,Tab, Figure ,Carousel} from 'react-bootstrap'
import {Route, Switch} from 'react-router-dom'
import Module from './Component/Module'
import StudentModule from './Component/StudentModule'
import img from './Component/image'
import './client.css'
export default function Client(){
    return (
        <>
              <div>
              <Navbar className="bg-nav" style={{ position: 'sticky',
                                top: '0',
                                zIndex: '1040',
                                
                            }}
                      collapseOnSelect expand="xl" bg="dark" variant="dark" className="justify-content-between" >
                    <Navbar.Brand >
                        <img
                          alt=""
                          src={img.logo}
                          width="170"
                          height="50"
                          className="d-inline-block align-top"
                        />{' '}
                    </Navbar.Brand>
                <Form inline>
                  <FormControl type="text" placeholder="Search" className="mr-sm-2" />
                  <Button variant="outline-light">Search</Button>
                </Form>
              </Navbar>
              <Jumbotron className="bg-cover" fluid style={{ 
                                    margin:'0 0',
                                    height: '100vh',
                                    position: 'sticky',
                                    top:'0', 
                                    zIndex:'600' }}>
                  <Container style={{
                                    position: 'absolute',
                                    left: '50%',
                                    top: '40%',
                                    transform:'translateX(-50%)',
                                    paddingLeft:'70px'
                                    }}>
                    <h1 style={{fontSize: '5em',color: 'white'}}>WELCOME TO WORKSPACE</h1>
                  </Container>
              </Jumbotron>
              
                   <Carousel fade="true" interval="2000" style={{
                    position:'sticky',top:'0', zIndex:'700',
                   }}>
                      <Carousel.Item>
                        <img
                          className="d-block w-100"
                          src={img.covid}
                          height="700px"
                          alt="First slide"
                        />
                        
                      </Carousel.Item>
                      <Carousel.Item>
                        <img
                          className="d-block w-100"
                          src={img.abroad}
                          height="700px"
                          alt="Third slide"
                        />

                      </Carousel.Item>
                      <Carousel.Item>
                        <img
                          className="d-block w-100"
                          src={img.vietcapital}
                          height="700px"
                          alt="Third slide"
                        />

                      </Carousel.Item>
                    </Carousel>

              <Jumbotron className="bg-schedule"style={{paddingTop:'80px',paddingBottom:'80px',position:'relative',top:'0', zIndex:'800', margin:'0 0'}}>
                  <Tabs defaultActiveKey="profile" id="uncontrolled-tab-example">
                  <Tab eventKey="profile" title="Schedule">
                      <Module/>
                  </Tab>
                  <Tab eventKey="Student list" title="Student list">
                      <StudentModule/>
                  </Tab>
                  <Tab eventKey="Attendance" title="Attendance" >
                    
                  </Tab>
                </Tabs>
              </Jumbotron>
              <footer>
                  <Jumbotron className="bg-footer" style={{textAlign: 'center' ,paddingTop:'20px',paddingBottom:'20px',position:'relative',top:'0',zIndex:'1000',margin:'0 0'}}>
                      <p>Face Regconition, Ltd. © 2020</p>
                  </Jumbotron>
              </footer>
              
              </div>
              
              
        </>
)
}
