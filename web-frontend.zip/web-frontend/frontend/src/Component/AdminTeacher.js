import React from 'react'
import AddTeacher from "../TeacherCRUD/AddTeacher"
import SearchTeacher from '../TeacherCRUD/searchTeacher'
import TeacherAdmin from '../TeacherCRUD/teacherAdmin'
import {Tab,Tabs, Nav } from 'react-bootstrap'

export default class AdminTeacher extends React.Component{
    render(){
        return(
         <>
            <Tabs defaultActiveKey="list" id="uncontrolled-tab-example">
            <Tab eventKey="list" title="Teacher List">
                <TeacherAdmin />
            </Tab>
            <Tab eventKey="add" title="Add Teacher">
                <AddTeacher />
            </Tab>
            <Tab eventKey="search" title="Search">
                <SearchTeacher />
            </Tab>
            </Tabs>
        </>
        )
    }
}