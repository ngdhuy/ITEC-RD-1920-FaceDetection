import React from 'react'
import AddClass from "../ClassCRUD/AddClass"
import ClassAdmin from '../ClassCRUD/ClassAdmin'
import {Tab,Tabs, Nav } from 'react-bootstrap'

export default class AdminClass extends React.Component{
    render(){
        return(
         <>
            <Tabs defaultActiveKey="list" id="uncontrolled-tab-example">
            <Tab eventKey="list" title="Class List">
                <ClassAdmin />
            </Tab>
            <Tab eventKey="add" title="Add Class">
                <AddClass />
            </Tab>
            </Tabs>
        </>
        )
    }
}