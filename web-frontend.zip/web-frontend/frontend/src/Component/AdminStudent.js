import React from 'react'
import AddStudent from "../StudentCRUD/AddStudent"
import SearchStudent from '../StudentCRUD/SearchStudent'
import StudentAdmin from '../StudentCRUD/StudentAdmin'
import {Tab,Tabs, Nav } from 'react-bootstrap'

export default class AdminStudent extends React.Component{
    render(){
        return(
         <>
            <Tabs defaultActiveKey="list" id="uncontrolled-tab-example">
            <Tab eventKey="list" title="Student List">
                <StudentAdmin />
            </Tab>
            <Tab eventKey="add" title="Add student">
                <AddStudent />
            </Tab>
            <Tab eventKey="search" title="Search">
                <SearchStudent />
            </Tab>
            </Tabs>
        </>
        )
    }
}