import React from 'react'
import {Table,Form,FormControl,Button} from 'react-bootstrap'
export default function StudentModule(){
    return(
        <>
        <div>
        <Form inline style={{
            display: 'flex',
            justifyContent: 'flex-end'
        }}>
            <FormControl type="text" placeholder="Search" className="mr-sm-2" />
            <Button variant="outline-success">Search</Button>
         </Form>
        </div>
          <Table responsive striped bordered hover variant="dark">
                <thead>
                    <tr>
                    <th>#</th>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Class</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Gender</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                    <td>1</td>
                    <td>1659001</td>
                    <td>Hồ Ngọc Hà</td>
                    <td>16bit</td>
                    <td>123@gmail.com</td>
                    <td>xxxxxxxxx</td>
                    <td>female</td>
                    </tr>
                    <tr>
                    <td>2</td>
                    <td>1659002</td>
                    <td>Lê Công vinh</td>
                    <td>16bit</td>
                    <td>456@gmail.com</td>
                    <td>xxxxxxxxx</td>
                    <td>male</td>
                    </tr>
                    <tr>
                    <td>3</td>
                    <td>1659003</td>
                    <td>Noo Phước Thịnh</td>
                    <td>16bit</td>
                    <td>789@gmail.com</td>
                    <td>xxxxxxxxx</td>
                    <td>male</td>
                    </tr>
                    <tr>
                    <td>4</td>
                    <td>1659004</td>
                    <td>Phạm Nhật Vượng</td>
                    <td>16bit</td>
                    <td>234@gmail.com</td>
                    <td>xxxxxxxxx</td>
                    <td>male</td>
                    </tr>
                    <tr>
                    <td>5</td>
                    <td>1659005</td>
                    <td>Mai Phương Thúy</td>
                    <td>16bit</td>
                    <td>134@gmail.com</td>
                    <td>xxxxxxxxx</td>
                    <td>female</td>
                    </tr>
                    <tr>
                    <td>6</td>
                    <td>1659006</td>
                    <td>Nguyễn Trần Trung Quân</td>
                    <td>16bit</td>
                    <td>134@gmail.com</td>
                    <td>xxxxxxxxx</td>
                    <td>male</td>
                    </tr>
                    <tr>
                    <td>7</td>
                    <td>1659007</td>
                    <td>Linda</td>
                    <td>16bit</td>
                    <td>098@gmail.com</td>
                    <td>xxxxxxxxx</td>
                    <td>fmale</td>
                    </tr>
                    <tr>
                    <td>8</td>
                    <td>1659008</td>
                    <td>Võ Hoàng Yến</td>
                    <td>16bit</td>
                    <td>288@gmail.com</td>
                    <td>xxxxxxxxx</td>
                    <td>female</td>
                    </tr>
                    <tr>
                    <td>9</td>
                    <td>1659009</td>
                    <td>Lê Quang Vinh</td>
                    <td>16bit</td>
                    <td>837@gmail.com</td>
                    <td>xxxxxxxxx</td>
                    <td>male</td>
                    </tr>
                    <tr>
                    <td>10</td>
                    <td>1659010</td>
                    <td>Chị Thỏ Ngọc</td>
                    <td>16bit</td>
                    <td>731@gmail.com</td>
                    <td>xxxxxxxxx</td>
                    <td>female</td>
                    </tr>
                </tbody>
            </Table>
        </>
    )

}