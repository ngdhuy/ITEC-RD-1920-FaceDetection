import React from 'react'
import AddCourse from "../CourseCRUD/AddCourse"
import SearchCourse from '../CourseCRUD/SearchCourse'
import CourseAdmin from '../CourseCRUD/CourseAdmin'
import {Tab,Tabs, Nav } from 'react-bootstrap'

export default class AdminCourse extends React.Component{
    render(){
        return(
         <>
            <Tabs defaultActiveKey="list" id="uncontrolled-tab-example">
            <Tab eventKey="list" title="Course List">
                <CourseAdmin />
            </Tab>
            <Tab eventKey="add" title="Add Course">
                <AddCourse />
            </Tab>
            <Tab eventKey="search" title="Search">
                <SearchCourse />
            </Tab>
            </Tabs>
        </>
        )
    }
}