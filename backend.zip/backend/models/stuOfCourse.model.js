
module.exports = (sequelize, Sequelize) => {
  const StuOfCourse = sequelize.define("student_of_course", {
    student_of_course_id:{
      type:Sequelize.INTEGER,
      autoIncrement: true,
      allowNull: false,
      primaryKey: true
    }
  ,student_id:{
    type:Sequelize.STRING,
  }
  ,coure_id:{
    type:Sequelize.STRING,
   }
  }
  ,
  { freezeTableName: true,
    timestamps: false
  });
return StuOfCourse;
 
};