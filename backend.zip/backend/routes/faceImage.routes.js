module.exports = app => {
  const face_image = require("../controllers/faceImage.controller.js");

  var router = require("express").Router();

  // Create a new Tutorial
  router.post("/", face_image.create);

  // Retrieve all Tutorials
  router.get("/", face_image.findAll);

  // // Retrieve all published Tutorials
  // router.get("/published", class_room.findAllPublished);

  // Retrieve a single Tutorial with id
  router.get("/:id", face_image.findOne);

  // Update a Tutorial with id
  router.put("/:id", face_image.update);

  // Delete a Tutorial with id
  router.delete("/:id", face_image.delete);

  // Create a new Tutorial
  router.delete("/", face_image.deleteAll);

  app.use('/api/faceimage', router);
};
