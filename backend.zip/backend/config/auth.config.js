module.exports = {
    secret: "son-secret-key"
  };