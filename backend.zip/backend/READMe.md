_Kết nối với database nằm trong db.config.js nên thay đổi để database hay host sao cho phù hợp 
_Vì dùng Jsonwebtoken và bcrypt để hash password nên quyền admin tạo manual mỗi khi restart backend:
1: Vào postman nhập url http://localhost:8080/api/auth/signup.
2: Chọn phương thước post.
3: Chọn Body>raw và paste đoạn json này vào:
{
    "username": "admin",
    "email": "admin@123.com",
    "password": "1234567",
    "roles": ["admin"]
}
4: bấm Send.
