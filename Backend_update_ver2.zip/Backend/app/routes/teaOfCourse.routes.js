module.exports = app => {
  const teaOfCourse = require("../controllers/teaOfCourse.controller.js");

  var router = require("express").Router();

  // Create a new Tutorial
  router.post("/", teaOfCourse.create);

  // Retrieve all Tutorials
  router.get("/", teaOfCourse.findAll);

  // // Retrieve all published Tutorials
  // router.get("/published", class_room.findAllPublished);

  // Retrieve a single Tutorial with id
  router.get("/:id", teaOfCourse.findOne);

  // Update a Tutorial with id
  router.put("/:id", teaOfCourse.update);

  // Delete a Tutorial with id
  router.delete("/:id", teaOfCourse.delete);

  // Create a new Tutorial
  router.delete("/", teaOfCourse.deleteAll);

  app.use('/api/teacherofcourse', router);
};
