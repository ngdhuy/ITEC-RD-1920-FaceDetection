import React, { Component } from 'react'
import { Container, Row, Col } from 'reactstrap'
import CourseDataService from "../services/course.service"
import TableAdmin from './tableAdmin'
import { CSVLink } from "react-csv"

class CourseAdmin extends Component {
 constructor(props){
   super(props);

   this.state = {courses: []}
 }

  getItems(){
    CourseDataService.getAll()
      .then(response => {
        console.log(response.data);
        this.setState({courses: response.data})
      })
      .catch(err => console.log(err))
  }

  componentDidMount(){
    this.getItems()
  }

  render() {
    return (
      <Container fluid >
        <Row>
          <Col>
            <h1 style={{margin: "20px 0"}}>Course List</h1>
            
          </Col>
        </Row>
        <Row>
          <Col>
            <CSVLink
              filename={"course-list.csv"}
              color="primary"
              style={{float: "left", marginRight: "10px"}}
              className="btn btn-primary"
              data={this.state.courses}>
              Download CSV
            </CSVLink>
            <TableAdmin courses={this.state.courses} />
          </Col>
        </Row>
      </Container>
    )
  }
}

export default CourseAdmin