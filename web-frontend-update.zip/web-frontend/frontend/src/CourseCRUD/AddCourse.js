import React, { Component } from "react";
import CourseDataService from "../services/course.service";

 class AddCourse extends Component {
  constructor(props) {
    super(props);
    this.onChangeCourseId = this.onChangeCourseId.bind(this);
    this.onChangeName = this.onChangeName.bind(this);
    this.onChangeStart = this.onChangeStart.bind(this);
    this.onChangeEnd = this.onChangeEnd.bind(this);
    this.saveCourse = this.saveCourse.bind(this);
    this.newCourse = this.newCourse.bind(this);

    this.state = {
      course_id: "",
      course_name: "",
      course_start_date: null,
      course_end_date: null,
      submitted: false
    };
  }

  onChangeCourseId(e) {
    this.setState({
      course_id: e.target.value
    });
  }

  onChangeName(e) {
    this.setState({
      course_name: e.target.value
    });
  }
  
  onChangeStart(e) {
    this.setState({
      course_start_date: e.target.value
    });
  }

  onChangeEnd(e) {
    this.setState({
      course_end_date: e.target.value
    });
  }


  saveCourse() {
    var data = {
      course_id: this.state.course_id,
      course_name: this.state.course_name,
      course_start_date: this.state.course_start_date,
      course_end_date: this.state.course_end_date
    };

    CourseDataService.create(data)
      .then(response => {
        this.setState({
          course_id: response.data.course_id,
          course_name: response.data.course_name,
          course_start_date: response.data.course_start_date,
          course_end_date: response.data.course_end_date
        });
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });

    this.setState({
      submitted: true
    });
  }

  newCourse() {
    this.setState({
      course_id: "",
      course_name: "",
      course_start_date: null,
      course_end_date: null,
      submitted: false
    });
  }

  render() {
    return (
      <div className="submit-form">
        {this.state.submitted ? (
          <div>
            <h4>You submitted successfully!</h4>
            <button className="btn btn-success" onClick={this.newCourse}>
              Add
            </button>
          </div>
        ) : (
          <div>
            <div className="form-group">
              <label htmlFor="course_id">ID</label>
              <input
                type="text"
                className="form-control"
                id="course_id"
                required
                value={this.state.course_id}
                onChange={this.onChangeCourseId}
                name="course_id"
              />
            </div>
            <div className="form-group">
              <label htmlFor="course_name">Course Name</label>
              <input
                type="text"
                className="form-control"
                id="course_name"
                required
                value={this.state.course_name}
                onChange={this.onChangeName}
                name="course_name"
              />
            </div>
            <div className="form-group">
              <label htmlFor="course_start_date">Start From</label>
              <input
                type="date"
                className="form-control"
                id="course_start_date"
                required
                value={this.state.course_start_date}
                onChange={this.onChangeStart}
                name="course_start_date"
              />
            </div>
            <div className="form-group">
              <label htmlFor="course_end_date">End Day</label>
              <input
                type="date"
                className="form-control"
                id="course_end_date"
                required
                value={this.state.course_end_date}
                onChange={this.onChangeEnd}
                name="course_end_date"
              />
            </div>
            <button onClick={this.saveCourse} className="btn btn-success">
              Submit
            </button>
          </div>
        )}
      </div>
    );
  }
}
export default AddCourse