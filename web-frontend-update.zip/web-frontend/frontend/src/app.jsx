import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import {Navbar,Nav} from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";

import AuthService from "./services/auth.service";

import Login from "./components/login.component";
import Register from "./components/register.component";
import Home from "./components/home.component";
import Profile from "./components/profile.component";
import BoardUser from "./components/board-user.component";
import BoardAdmin from "./components/board-admin.component";
import img from './Component/image';

class App extends Component {
  constructor(props) {
    super(props);
    this.logOut = this.logOut.bind(this);

    this.state = {
      showAdminBoard: false,
      currentUser: undefined
    };
  }

  componentDidMount() {
    const user = AuthService.getCurrentUser();

    if (user) {
      this.setState({
        currentUser: AuthService.getCurrentUser(),
        showAdminBoard: user.roles.includes("ROLE_ADMIN")
      });
    }
  }

  logOut() {
    AuthService.logout();
  }


  render() {
    const { currentUser, showAdminBoard } = this.state;

    return (
      <Router>
        <>
        <Navbar collapseOnSelect expand="lg" sticky="top" bg="primary" variant="dark" >
        <Navbar.Brand >
                        <img
                          alt=""
                          src={img.logo}
                          width="170"
                          height="50"
                          className="d-inline-block align-top"
                        />{' '}
                    </Navbar.Brand>
    <Navbar.Toggle aria-controls="responsive-navbar-nav" />
  <Navbar.Collapse id="responsive-navbar-nav" >
    <Nav className="mr-auto ">
      {showAdminBoard && (<Nav.Link href="/admin/teacher">Admin Page</Nav.Link>)}
      {currentUser && (<Nav.Link href="/user">User Page</Nav.Link>)}
      {currentUser 
      ? 
      <Nav className="mr-auto " >
      <Nav.Link  href="/login" onClick={this.logOut}>logOut</Nav.Link>  
      </Nav>
      :
      <>
      <Nav className="mr-auto">
       <Nav.Link href="/login">Sign In</Nav.Link>
       <Nav.Link href="/register">Sign Up</Nav.Link>
       </Nav>
      </>
       }
    </Nav>
    </Navbar.Collapse>
    
  </Navbar>

          
          <div >
            <Switch>
              <Route exact path={["/", "/home"]} component={Home} />
              <Route exact path="/login" component={Login} />
              <Route exact path="/register" component={Register} />
              <Route exact path="/profile" component={Profile} />
              <Route path="/user" component={BoardUser} />
              <Route path="/admin" component={BoardAdmin} />
            </Switch>
          </div>
        </>
      </Router>
    );
  }
}

export default App;