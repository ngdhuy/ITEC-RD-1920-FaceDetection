import React, { Component } from "react";
import {Jumbotron, Container} from "react-bootstrap";
import './homeComponent.css';

export default class Home extends Component {

  render() {
    return (
        <Jumbotron fluid className="landing-home">
          
          
        </Jumbotron>
    );
  }
}