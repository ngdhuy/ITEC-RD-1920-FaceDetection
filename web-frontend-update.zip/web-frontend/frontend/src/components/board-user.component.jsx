import React, { Component } from "react";

import UserService from "../services/user.service";
import {Nav,Navbar,Form,FormControl,Button, Container, Jumbotron,Row, Col,Tabs,Tab, Figure ,Carousel, Media} from 'react-bootstrap'
import {Route, Switch} from 'react-router-dom'
import Module from '../Component/Module'
import StudentModule from '../Component/StudentModule'
import img from '../Component/image'
import '../client.css'
export default class BoardUser extends Component {

  render() {
    return (
 
        <div>
                
              <Jumbotron className="bg-cover" fluid style={{ 
                                    margin:'0 0',
                                    height: '100vh',
                                    position: 'sticky',
                                    top:'0', 
                                    zIndex:'600' }}>
                  <Container style={{
                                    position: 'absolute',
                                    left: '50%',
                                    top: '40%',
                                    transform:'translateX(-50%)',
                                    paddingLeft:'70px',
                                    
                                    }}>
                    <h1 className="landing-text" >WELCOME TO WORKSPACE</h1>
                  </Container>
              </Jumbotron>
              
                   <Carousel fade="true" interval="2000" style={{
                    position:'sticky',top:'0', zIndex:'700',
                   }}>
                      <Carousel.Item>
                        <img
                          className="d-block w-100"
                          src={img.covid}
                          height="700px"
                          alt="First slide"
                        />
                        
                      </Carousel.Item>
                      <Carousel.Item>
                        <img
                          className="d-block w-100"
                          src={img.abroad}
                          height="700px"
                          alt="Third slide"
                        />

                      </Carousel.Item>
                      <Carousel.Item>
                        <img
                          className="d-block w-100"
                          src={img.vietcapital}
                          height="700px"
                          alt="Third slide"
                        />

                      </Carousel.Item>
                    </Carousel>

              <Jumbotron className="bg-schedule"style={{paddingTop:'80px',paddingBottom:'80px',position:'relative',top:'0', zIndex:'800', margin:'0 0'}}>
                  <Tabs defaultActiveKey="profile" id="uncontrolled-tab-example">
                  <Tab eventKey="profile" title="Schedule">
                      <Module/>
                  </Tab>
                  <Tab eventKey="Student list" title="Student list">
                      <StudentModule/>
                  </Tab>
                  <Tab eventKey="Attendance" title="Attendance" >
                    
                  </Tab>
                </Tabs>
              </Jumbotron>
              
              </div>

    );
  }
}