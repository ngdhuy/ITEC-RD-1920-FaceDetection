import React, { Component } from "react";
import {Navbar, Nav, Form, FormControl, Button, Container} from 'react-bootstrap'
import {BrowserRouter as Router, Switch, Route, Link} from 'react-router-dom'
import AdminTeacher from "../Component/AdminTeacher"
import AdminStudent from "../Component/AdminStudent"
import AdminCourse from "../Component/AdminCourse"
import AdminClass from "../Component/AdminClass"
export default class BoardAdmin extends Component {

  render() {
    return (
       <Router>
        <Navbar bg="light" expand="lg">
          <Navbar.Brand href="#home">ADMIN PAGE</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="mr-auto">
              <Nav.Link href="/admin/teacher">Teacher</Nav.Link>
              <Nav.Link href="/admin/student">Student</Nav.Link>
              <Nav.Link href="/admin/course">Course</Nav.Link>
              <Nav.Link href="/admin/class">Class</Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Navbar>
        <Container>
          <Switch>
            <Route exact path="/admin/teacher" component={AdminTeacher}></Route>
            <Route exact path="/admin/student" component={AdminStudent}></Route>
            <Route exact path="/admin/course" component={AdminCourse}></Route>
            <Route exact path="/admin/class" component={AdminClass}></Route>
          </Switch>
        </Container>
      </Router>
    );
  }
}