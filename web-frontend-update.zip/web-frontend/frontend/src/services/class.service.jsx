import http from "../http-common";

class ClassDataService {
  getAll() {
    return http.get("/class");
  }

  get(class_id) {
    return http.get(`/class/${class_id}`);
  }

  create(data) {
    return http.post("/class", data);
  }

  update(class_id, data) {
    return http.put(`/class/${class_id}`, data);
  }

  delete(class_id) {
    return http.delete(`/class/${class_id}`);
  }

  deleteAll() {
    return http.delete(`/class`);
  }
}

export default new ClassDataService();