import http from "../http-common";

class StudentDataService {
  getAll() {
    return http.get("/student");
  }

  get(student_id) {
    return http.get(`/student/${student_id}`);
  }

  create(data) {
    return http.post("/student", data);
  }

  update(student_id, data) {
    return http.put(`/student/${student_id}`, data);
  }

  delete(student_id) {
    return http.delete(`/student/${student_id}`);
  }

  deleteAll() {
    return http.delete(`/student`);
  }

  findByName(name) {
    return http.get(`/student?name=${name}`);
  }
}

export default new StudentDataService();