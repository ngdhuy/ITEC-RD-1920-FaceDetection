import React, { Component } from "react"
import TeacherDataService from "../services/teacher.service"

export default class Update extends Component {
    constructor(props) {
        super(props);
        this.onChangeTeacherId = this.onChangeTeacherId.bind(this);
        this.onChangeName = this.onChangeName.bind(this);
        this.onChangeEmail = this.onChangeEmail.bind(this);
        this.onChangePhone = this.onChangePhone.bind(this);
        this.onChangeGender = this.onChangeGender.bind(this);
        this.getTeacher = this.getTeacher.bind(this);
        this.update = this.update.bind(this);
        this.deleteTeacher = this.deleteTeacher.bind(this);

        this.state = {
            currentTeacher: {
                teacher_id: null,
                name: "",
                email: "",
                phone: "",
                gender: ""
            },
            message: ""
        };
    }

    componentDidMount() {
        this.getTeacher(this.props.match.params.teacher_id);
    }

    onChangeTeacherId(e) {
        const teacher_id = e.target.value;

        this.setState(prevState => ({
            currentTeacher: {
                ...prevState.currentTeacher,
                teacher_id: teacher_id
            }
        }));
    }

    onChangeName(e) {
        const name = e.target.value;

        this.setState(prevState => ({
            currentTeacher: {
                ...prevState.currentTeacher,
                name: name
            }
        }));
    }

    onChangeEmail(e) {
        const email = e.target.value;

        this.setState(prevState => ({
            currentTeacher: {
                ...prevState.currentTeacher,
                email: email
            }
        }));
    }

    onChangePhone(e) {
        const phone = e.target.value;

        this.setState(prevState => ({
            currentTeacher: {
                ...prevState.currentTeacher,
                phone: phone
            }
        }));
    }

    onChangeGender(e) {
        const gender = e.target.value;

        this.setState(prevState => ({
            currentTeacher: {
                ...prevState.currentTeacher,
                gender: gender
            }
        }));
    }

    getTeacher(teacher_id) {
        TeacherDataService.get(teacher_id)
            .then(response => {
                this.setState({
                    currentTeacher: response.data
                });
                console.log(response.data);
            })
            .catch(e => {
                console.log(e);
            });
    }

    update() {
        var data = {
            teacher_id: this.state.currentTeacher.teacher_id,
            name: this.state.currentTeacher.name,
            email: this.state.currentTeacher.email,
            phone: this.state.currentTeacher.phone,
            gender: this.state.currentTeacher.gender
        };

        TeacherDataService.update(this.state.currentTeacher.teacher_id, data)
            .then(response => {
                this.setState(prevState => ({
                    currentTeacher: {
                        ...prevState.currentTeacher
                    }
                }));
                console.log(response.data);
                this.setState({
                    message: "the teacher was updates successfully!"
                });
            })
            .catch(e => {
                console.log(e);
            }); 
    }
    deleteTeacher(){
        TeacherDataService.delete(this.state.currentTeacher.teacher_id)
            .then(response => {
                console.log(response.data);
                this.props.history.push('/teacher')
            })
            .catch(e => {
                console.log(e);
            });
    }
}