import React, { Component } from 'react'
import { Table, Button, Row, Col } from 'react-bootstrap';
import StudentDataService from '../services/student.service'


class TableAdmin extends Component {
  constructor(props){
    super(props);
    this.del = this.del.bind(this);

  }
  del(student_id){
    let confirmDelete = window.confirm('Delete item forever?')
    if(confirmDelete)
    StudentDataService.delete(student_id)
    .then(response => {
      console.log(response.data);
      this.props.history.push('/student')
      })
      .catch(e => {
          console.log(e);
      });
  }
  render() {

    const students = this.props.students.map(student => {
      return (
        <tr key={student.id}>
          <th scope="row">{student.student_id}</th>
          <td>{student.name}</td>
          <td>{student.email}</td>
          <td>{student.phone}</td>
          <td>{student.gender}</td>
          <td>{student.class_id}</td>
          <td>
            <Button variant="outline-warning">Edit</Button>{' '}
            <Button variant="outline-danger" onClick={() => this.del(student.student_id)}>Delete</Button>
          </td>
          <td>
          </td>
        </tr>
        )
      })

    return (
        
            <Table borderless responsive hover>
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Gender</th>
            <th>Class ID</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {students}
        </tbody>
      </Table>
      
    )
  }
}

export default TableAdmin