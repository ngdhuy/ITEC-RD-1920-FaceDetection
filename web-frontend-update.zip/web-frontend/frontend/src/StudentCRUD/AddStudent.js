import React, { Component } from "react";
import StudentDataService from "../services/student.service";

 class AddStudent extends Component {
  constructor(props) {
    super(props);
    this.onChangeName = this.onChangeName.bind(this);
    this.onChangeStudentId = this.onChangeStudentId.bind(this);
    this.onChangeEmail = this.onChangeEmail.bind(this);
    this.onChangePhone = this.onChangePhone.bind(this);
    this.onChangeGender = this.onChangeGender.bind(this);
    this.onChangeClassId = this.onChangeClassId.bind(this);
    this.saveStudent = this.saveStudent.bind(this);
    this.newStudent = this.newStudent.bind(this);

    this.state = {
      student_id: null,
      name: "",
      email: "",
      phone: null,
      gender: "",
      class_id: null,
      submitted: false
    };
  }

  onChangeStudentId(e) {
    this.setState({
      student_id: e.target.value
    });
  }

  onChangeName(e) {
    this.setState({
      name: e.target.value
    });
  }
  
  onChangeEmail(e) {
    this.setState({
      email: e.target.value
    });
  }

  onChangePhone(e) {
    this.setState({
      phone: e.target.value
    });
  }

  onChangeGender(e) {
    this.setState({
      gender: e.target.value
    });
  }

  onChangeClassId(e) {
    this.setState({
      class_id: e.target.value
    });
  }

  saveStudent() {
    var data = {
      student_id: this.state.student_id,
      name: this.state.name,
      email: this.state.email,
      phone: this.state.phone,
      gender: this.state.gender,
      class_id: this.state.class_id
    };

    StudentDataService.create(data)
      .then(response => {
        this.setState({
          student_id: response.data.student_id,
          name: response.data.name,
          email: response.data.email,
          phone: response.data.phone,
          gender: response.data.gender,
          class_id: response.data.class_id
        });
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });

    this.setState({
      submitted: true
    });
  }

  newStudent() {
    this.setState({
      student_id: null,
      name: "",
      email: "",
      phone: null,
      gender: "",
      class_id: null,
      submitted: false
    });
  }

  render() {
    return (
      <div className="submit-form">
        {this.state.submitted ? (
          <div>
            <h4>You submitted successfully!</h4>
            <button className="btn btn-success" onClick={this.newStudent}>
              Add
            </button>
          </div>
        ) : (
          <div>
            <div className="form-group">
              <label htmlFor="student_id">ID</label>
              <input
                type="number"
                className="form-control"
                id="student_id"
                required
                value={this.state.student_id}
                onChange={this.onChangeStudentId}
                name="student_id"
              />
            </div>
            <div className="form-group">
              <label htmlFor="name">name</label>
              <input
                type="text"
                className="form-control"
                id="name"
                required
                value={this.state.name}
                onChange={this.onChangeName}
                name="name"
              />
            </div>
            <div className="form-group">
              <label htmlFor="email">Email</label>
              <input
                type="email"
                className="form-control"
                id="email"
                required
                value={this.state.email}
                onChange={this.onChangeEmail}
                name="email"
                placeholder="ex ABC@gmail.com"
              />
            </div>
            <div className="form-group">
              <label htmlFor="phone">Phone</label>
              <input
                type="number"
                className="form-control"
                id="phone"
                required
                value={this.state.phone}
                onChange={this.onChangePhone}
                name="phone"
                placeholder="ex 07x xxx xxxx"
              />
            </div>
            <div className="form-group">
              <label htmlFor="gender">Gender</label>
              <input
                type="text"
                className="form-control"
                id="gender"
                required
                value={this.state.gender}
                onChange={this.onChangeGender}
                name="gender"
                placeholder="male / female"
              />
            </div>
            <div className="form-group">
              <label htmlFor="class_id">Class ID</label>
              <input
                type="number"
                className="form-control"
                id="class_id"
                required
                value={this.state.class_id}
                onChange={this.onChangeClassId}
                name="class_id"
              />
            </div>
            <button onClick={this.saveStudent} className="btn btn-success">
              Submit
            </button>
          </div>
        )}
      </div>
    );
  }
}
export default AddStudent