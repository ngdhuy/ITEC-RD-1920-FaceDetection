import React, { Component } from 'react'
import { Container, Row, Col } from 'reactstrap'
import ClassDataService from "../services/class.service"
import TableAdmin from './tableAdmin'
import { CSVLink } from "react-csv"

class ClassAdmin extends Component {
 constructor(props){
   super(props);

   this.state = {classes: []}
 }

  getItems(){
    ClassDataService.getAll()
      .then(response => {
        console.log(response.data);
        this.setState({classes: response.data})
      })
      .catch(err => console.log(err))
  }

  componentDidMount(){
    this.getItems()
  }

  render() {
    return (
      <Container fluid >
        <Row>
          <Col>
            <h1 style={{margin: "20px 0"}}>Class List</h1>
            
          </Col>
        </Row>
        <Row>
          <Col>
            <CSVLink
              filename={"class-list.csv"}
              color="primary"
              style={{float: "left", marginRight: "10px"}}
              className="btn btn-primary"
              data={this.state.classes}>
              Download CSV
            </CSVLink>
            <TableAdmin classes={this.state.classes} />
          </Col>
        </Row>
      </Container>
    )
  }
}

export default ClassAdmin