import React, { Component } from "react";
import TeacherDataService from "../services/teacher.service";

 class AddTeacher extends Component {
  constructor(props) {
    super(props);
    this.onChangeName = this.onChangeName.bind(this);
    this.onChangeTeacherId = this.onChangeTeacherId.bind(this);
    this.onChangeEmail = this.onChangeEmail.bind(this);
    this.onChangePhone = this.onChangePhone.bind(this);
    this.onChangeGender = this.onChangeGender.bind(this);
    this.saveTutorial = this.saveTutorial.bind(this);
    this.newTutorial = this.newTutorial.bind(this);

    this.state = {
      teacher_id: null,
      name: "",
      email:"",
      phone:"",
      gender:"",
      submitted: false
    };
  }

  onChangeTeacherId(e) {
    this.setState({
      teacher_id: e.target.value
    });
  }

  onChangeName(e) {
    this.setState({
      name: e.target.value
    });
  }
  
  onChangeEmail(e) {
    this.setState({
      email: e.target.value
    });
  }

  onChangePhone(e) {
    this.setState({
      phone: e.target.value
    });
  }

  onChangeGender(e) {
    this.setState({
      gender: e.target.value
    });
  }

  saveTutorial() {
    var data = {
      teacher_id: this.state.teacher_id,
      name: this.state.name,
      email: this.state.email,
      phone: this.state.phone,
      gender: this.state.gender
    };

    TeacherDataService.create(data)
      .then(response => {
        this.setState({
          teacher_id: response.data.teacher_id,
          name: response.data.name,
          email: response.data.email,
          phone: response.data.phone,
          gender: response.data.gender
        });
        console.log(response.data);
      })
      .catch(e => {
        console.log(e);
      });

    this.setState({
      submitted: true
    });
  }

  newTutorial() {
    this.setState({
      teacher_id: null,
      name: "",
      email: "",
      phone: null,
      gender: "",
      submitted: false
    });
  }

  render() {
    return (
      <div className="submit-form">
        {this.state.submitted ? (
          <div>
            <h4>You submitted successfully!</h4>
            <button className="btn btn-success" onClick={this.newTutorial}>
              Add
            </button>
          </div>
        ) : (
          <div>
            <div className="form-group">
              <label htmlFor="teacher_id">ID</label>
              <input
                type="number"
                className="form-control"
                id="teacher_id"
                required
                value={this.state.teacher_id}
                onChange={this.onChangeTeacherId}
                name="teacher_id"
              />
            </div>
            <div className="form-group">
              <label htmlFor="name">name</label>
              <input
                type="text"
                className="form-control"
                id="name"
                required
                value={this.state.name}
                onChange={this.onChangeName}
                name="name"
              />
            </div>
            <div className="form-group">
              <label htmlFor="email">Email</label>
              <input
                type="email"
                className="form-control"
                id="email"
                required
                value={this.state.email}
                onChange={this.onChangeEmail}
                name="email"
                placeholder="ex ABC@gmail.com"
              />
            </div>
            <div className="form-group">
              <label htmlFor="phone">Phone</label>
              <input
                type="number"
                className="form-control"
                id="phone"
                required
                value={this.state.phone}
                onChange={this.onChangePhone}
                name="phone"
                placeholder="ex 07x xxx xxxx"
              />
            </div>
            <div className="form-group">
              <label htmlFor="gender">Gender</label>
              <input
                type="text"
                className="form-control"
                id="gender"
                required
                value={this.state.gender}
                onChange={this.onChangeGender}
                name="gender"
                placeholder="male / female"
              />
            </div>

            <button onClick={this.saveTutorial} className="btn btn-success">
              Submit
            </button>
          </div>
        )}
      </div>
    );
  }
}
export default AddTeacher