import React, { Component } from 'react'
import { Container, Row, Col } from 'reactstrap'
import TeacherDataService from "../services/teacher.service"
import TableAdmin from './tableAdmin'
import { CSVLink } from "react-csv"

class TeacherAdmin extends Component {
 constructor(props){
   super(props);

   this.state = {teachers: []}
 }

  getItems(){
    TeacherDataService.getAll()
      .then(response => {
        console.log(response.data);
        this.setState({teachers: response.data})
      })
      .catch(err => console.log(err))
  }

  componentDidMount(){
    this.getItems()
  }

  render() {
    return (
      <Container fluid >
        <Row>
          <Col>
            <h1 style={{margin: "20px 0"}}>Teacher List</h1>
            
          </Col>
        </Row>
        <Row>
          <Col>
            <CSVLink
              filename={"teacher-list.csv"}
              color="primary"
              style={{float: "left", marginRight: "10px"}}
              className="btn btn-primary"
              data={this.state.teachers}>
              Download CSV
            </CSVLink>
            <TableAdmin teachers={this.state.teachers} />
          </Col>
        </Row>
      </Container>
    )
  }
}

export default TeacherAdmin