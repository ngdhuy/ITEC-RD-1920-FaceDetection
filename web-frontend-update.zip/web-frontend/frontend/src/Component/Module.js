import React from 'react'
import {Row,Table,Col} from  'react-bootstrap'
import Calendar from './calendar'

export default function Module(){
            
            return(
                <>
                <h1 style={{fontSize:'60px'}}>
                    MY SCHEDULE
                </h1>
                <br/>
                <br/>
                <Row >
                    <Col sm="4" style={{paddingBottom:'60px'}}>
                        <Calendar/>
                    </Col>
                    <Col >
                        <Table  responsive bordered hover  >
                            <thead style={{
                            backgroundColor: '#2c92ff',
                            color: 'white',
                            textAlign: 'center',

                            }}>
                            <tr>
                                <th style={{width:'60em'}}>

                                </th>
                                <th style={{width:'60em'}}>
                                    Sunday
                                </th>
                                <th style={{width:'60em'}}>
                                    Monday
                                </th>
                                <th style={{width:'60em'}}>
                                    Tuesday
                                </th>
                                <th style={{width:'60em'}}>
                                    Thursday
                                </th>
                                <th>
                                    Wednesday
                                </th>
                                <th style={{width:'60em'}}>
                                    Friday
                                </th>
                                <th style={{width:'60em'}}>
                                    Saturday
                                </th>
                            </tr>
                            </thead>
                            <tbody style={{backgroundColor:'#E0F8F7'}}>
                                <tr>
                                <td style={{backgroundColor:'#2c92ff',color:'white'}}>
                                    <p>8:00 - 10:00</p>
                                </td>
                                <td style={{backgroundColor: '#8cd9f8'}}>
                                    <p>Data Structure</p>
                                </td>
                                <td>
                                    
                                </td>
                                <td style={{backgroundColor: '#8cd9f8'}}>
                                    <p>Advanced Database</p>
                                </td> 
                                <td>

                                </td>
                                <td>
                                    
                                </td>
                                <td>

                                </td>
                                <td style={{backgroundColor: '#8cd9f8'}}>
                                    <p>Networking</p>
                                </td>
                                </tr>
                                <tr>
                                <td style={{backgroundColor:'#2c92ff',color:'white'}}>
                                    <p>11:00 - 13:00</p>
                                </td>
                                <td>
                                    
                                </td>
                                <td>
                                    
                                </td>
                                <td style={{backgroundColor: '#8cd9f8'}}>
                                    <p>Advanced Database</p>
                                </td> 
                                <td>

                                </td>
                                <td style={{backgroundColor: '#8cd9f8'}}>
                                    <p>English</p>
                                </td>
                                <td>

                                </td>
                                <td>
                                    
                                </td>
                                </tr>
                                <tr>
                                <td style={{backgroundColor:'#2c92ff',color:'white'}}>
                                    <p>14:00 - 16:00</p>
                                </td>
                                <td>
                                    
                                </td>
                                <td style={{backgroundColor: '#8cd9f8'}}>
                                    <p>Algorithms</p>
                                </td>
                                <td>
                                    
                                </td> 
                                <td>

                                </td>
                                <td style={{backgroundColor: '#8cd9f8'}}>
                                    <p>English</p>
                                </td>
                                <td>

                                </td>
                                <td style={{backgroundColor: '#8cd9f8'}}>
                                    <p>Networking</p>
                                </td>
                                </tr>
                            </tbody>
                        </Table>
                    </Col>
                </Row>
                </>
                )
}