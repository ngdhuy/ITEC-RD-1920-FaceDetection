const image = {
    itec: require('../image/itec.png'),
    khtn: require('../image/khtn.png'),
    background: require('../image/background.jpg'),
    landing: require('../image/landing.jpg'),
    logo: require('../image/logo.png'),
    An: require('../image/Avatar-1.png'),
    Jin: require('../image/Avatar-3.png'),
    Son: require('../image/Avatar-2.png'),
    Huy: require('../image/Avatar-4.png'),
    abroad: require('../image/abroad.jpg'),
    covid: require('../image/covid.png'),
    vietcapital: require('../image/Vietcapital.png')
};
 
export default image