import React, {Component} from 'react';
import {Navbar, Nav, Form, FormControl, Button, Container} from 'react-bootstrap'
import {BrowserRouter as Router, Switch, Route, Link} from 'react-router-dom'
import AdminTeacher from "./Component/AdminTeacher"
import AdminStudent from "./Component/AdminStudent"
import AdminCourse from "./Component/AdminCourse"
import AdminClass from "./Component/AdminClass"

class Admin extends Component{
  render(){
    return(
      <Router>
        <Navbar bg="light" expand="lg">
          <Navbar.Brand href="#home">ADMIN PAGE</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="mr-auto">
              <Nav.Link href="/teacher">Teacher</Nav.Link>
              <Nav.Link href="/student">Student</Nav.Link>
              <Nav.Link href="/course">Course</Nav.Link>
              <Nav.Link href="/class">Class</Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Navbar>
        <Container>
          <Switch>
            <Route exact path="/teacher" component={AdminTeacher}></Route>
            <Route exact path="/student" component={AdminStudent}></Route>
            <Route exact path="/course" component={AdminCourse}></Route>
            <Route exact path="/class" component={AdminClass}></Route>
          </Switch>
        </Container>
      </Router>
    )
  }
}

export default Admin;
